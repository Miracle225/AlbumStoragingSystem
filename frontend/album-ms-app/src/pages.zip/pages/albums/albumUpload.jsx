import React, { useState } from 'react';
import axios from 'axios';
import Header from './albums/header';
import { Box, Button, Container, Grid, Paper, Typography, IconButton } from '@mui/material';
import { makeStyles } from '@mui-styles';
import { AddCircleOutline, Close } from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';

const useStyles = makeStyles((theme) => ({
  dropzoneContainer: {
    border: `2px dashed ${theme.palette.primary.main}`,
    borderRadius: theme.spacing(2),
    padding: theme.spacing(4),
    textAlign: 'center',
    cursor: 'pointer'
  },
  uploadedFile: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: theme.spacing(2),
    marginTop: theme.spacing(2),
    border: `1px solid ${theme.palette.secondary.main}`,
    borderRadius: theme.spacing(1)
  }
}));

export default function FileUploadPage(){
  const classes = useStyles();
  const [files, setFiles] = useState();
  const onDrop = (acceptedFiles) => {
    setFiles((prevFiles) => [...prevFiles, ...acceptedFiles]);
  };
  const { getRootProps, getInputProps } = useDropzone({ onDrop });
  const removeFile = (index) => {
    setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index));
  };
  const handleUpload = async () => {
    try {
      const formData = new FormData();
      files.forEach((file) => {
        formData.append('files', file);
      });

      const token = localStorage.getItem('token');
      const response = await axios.post('/api/v1/album/1/upload-photos', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`
        }
      });
      console.log('Upload succesful:', response.data);
      setFiles([]);
    } catch (error) {
      console.error('Error uploading files:', error.message);
    }
  };

  return (
    <div>
      <Header />
      <Container>
        <Paper elevation={3} style={{ padding: '20px', marginTop: '20px' }}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Typography variant="h4" align="center" gutterBottom>
                Photo Upload
              </Typography>
            </Grid>
            <Grid item xs={12} {...getRootProps()}>
              <input {...getInputProps()} />
              <Paper elevation={3} className={classes.dropzoneContainer}>
                <AddCircleOutline fontSize="large" color="primary" />
                <Typography variant="h6">Drag and drop photos or click to select files</Typography>
              </Paper>
            </Grid>
            <Grid item xs={12}>
              <Box>
                {files.map((file, index) => (
                  <Paper key={index} elevation={3} className={classes.uploadedFile}>
                    <Typography>{file.name}</Typography>
                    <IconButton onClick={() => removeFile(index)} color="secondary">
                      <Close />
                    </IconButton>
                  </Paper>
                ))}
              </Box>
            </Grid>
            <Grid item xs={12}>
              <Button variant="contained" color="primary" onClick={handleUpload} disabled={files.length === 0}>
                Upload photos
              </Button>
            </Grid>
          </Grid>
        </Paper>
      </Container>
    </div>
  );
};