import React from "react";
import Header from "./albums/header";

export default function Albums(){
    return (
        <div>
            <Header/>
            <div style={{marginTop: '20px', padding: '20px'}}>
                Hi
            </div>
        </div>
    )
}
