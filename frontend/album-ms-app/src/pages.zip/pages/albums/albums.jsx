// material-ui
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card'; // Import Card
import CardContent from '@mui/material/CardContent';
import Grid from '@mui/material/Grid'; // Import Grid from @mui/material

// project imports
import MainCard from 'components/MainCard';
import { Link, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
// Corrected import path from relative path
import { fetchGetDataWithAuth } from '../../client/client';
// ==============================|| SAMPLE PAGE ||============================== //

// A more coordinated, modern color palette where white text will look good.
const cardColors = [
  '#264653',
  '#2a9d8f',
  '#e76f51',
  '#0077b6',
  '#00b4d8',
  '#fb8500',
  '#6f1d1b',
  '#5856D6',
  '#007AFF',
  '#577590',
  '#43aa8b',
  '#e9c46a'
];

const getRandomColor = () => {
  const randomIndex = Math.floor(Math.random() * cardColors.length);
  return cardColors[randomIndex];
};

// We don't need useStyles or makeStyles anymore!

export default function AlbumDynamicGridPage(){
  const [dataArray, setDataArray] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('token');
    if (!isLoggedIn) {
      navigate('/login');
      // It's better to return here to stop execution
      return;
    }

    fetchGetDataWithAuth('/album/getAll')
      .then((res) => {
        // Log the data you received, *not* the state variable
        console.log('Data received from API:', res.data);
        setDataArray(res.data);
      })
      .catch((err) => {
        console.error('Error fetching albums:', err);
        // Handle error, e.g., if token expired, navigate to login
        if (err.response && (err.response.status === 401 || err.response.status === 403)) {
          navigate('/login');
        }
      });
  }, [navigate]); // Add navigate as a dependency

  return (
    <Grid container spacing={3}>
      {/* Use a better key if data.id is available, otherwise fall back to index */}
      {dataArray.map((data, index) => (
        <Grid item key={index} xs={12} sm={6} md={4} lg={3}>
          <Link to={`/album/show?id=${data.id}`}>
          <Card
            sx={{
              backgroundColor: getRandomColor(), // Apply random color
              textAlign: 'center',
              padding: 3, // theme.spacing(3)
              borderRadius: 2, // theme.spacing(2)
              minHeight: '200px', // Use minHeight instead of fixed height
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center', // Center content horizontally
              cursor: 'pointer', // Show it's clickable
              transition: 'transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out',
              '&:hover': {
                transform: 'scale(1.03)', // Grow effect
                boxShadow: '0 10px 20px rgba(0,0,0,0.1)', // Add a subtle shadow
              }
            }}
          >
            <CardContent>
              {/* Use Typography component for better theme integration */}
              <Typography
                variant="h4"
                component="h2"
                sx={{
                  color: 'white',
                  fontWeight: '600',
                  fontSize: '1.75rem', // Slightly smaller font
                  wordBreak: 'break-word' // Prevent long names from overflowing
                }}
              >
                {data.name}
              </Typography>
            </CardContent>
          </Card>
          </Link>
        </Grid>
      ))}
    </Grid>
  );
};


